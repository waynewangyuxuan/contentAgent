export async function fetchStatus() {
  const response = await fetch("/api/status")
  if (!response.ok) {
    throw new Error("Failed to fetch status")
  }
  return response.json()
}
